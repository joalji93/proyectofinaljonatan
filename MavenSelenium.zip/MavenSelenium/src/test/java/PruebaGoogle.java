import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class PruebaGoogle  {
    static WebDriver driver;
    public static void main(String[]args){

        // En la siguiente linea hay que modificar la ruta de donde tengamos el archivo chromeDriver
        // Si colocamos la carpeta de automatización en el escritorio solo debemos cambiar la ruta del usuario
        System.setProperty("webdriver.chrome.driver", "C:\\webdriver\\chromedriver.exe");
        String baseURL = "https://proyectofinaljonatan.herokuapp.com/";

        driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.get(baseURL);

        try{
            //La prueba seguirá el orden establecido abajo
            //Podremos usar para definir el elemento el id si lo tuviera y sino con el xpath para buscar en la pagina

            // Aqui definimos las rutas que tomaremos.
            // Botones a pulsar, enlaces en los que clicar o formularios que rellenar
            WebElement enlaces = driver.findElement(By.xpath("//li[@id='enlace']/a"));
            //Aquí se definen los pasos a seguir con los enlaces de arriba
            // *tip* si haces ctrl+click en los nombres de la funcione muestra las rutas definidas para esa funcion
            enlaces.click(); //click como su nombre indica es para hacer click
            Thread.sleep(3000);

            WebElement manual = driver.findElement(By.xpath("//a[contains(@href,'drive')]"));
            Assert.assertNotNull(manual);
            Thread.sleep(2000);
            WebElement prezi = driver.findElement(By.xpath("//a[contains(@href,'prezi')]")); //Aquí esta el error para la prueba 'prezi' debe ir entre comillas simples
            Assert.assertNotNull(prezi);
            Thread.sleep(2000);

            System.out.println("Test 1 enlaces: Correcto");
        } catch (Exception e) {
            System.out.println("Test 1 enlaces: Error");
        }

        try{
            WebElement tabla = driver.findElement(By.xpath("//li[@id='tabla']/a"));
            tabla.click();
            Thread.sleep(3000);

            WebElement tabla1 = driver.findElement(By.xpath("//td//a[@href='/tabla1']"));
            tabla1.click();
            Thread.sleep(1000);

            WebElement tabla2 = driver.findElement(By.xpath("//td//a[@href='/tabla2']"));
            tabla2.click();
            Thread.sleep(1000);

            WebElement tabla3 = driver.findElement(By.xpath("//td//a[@href='/tabla3']"));
            tabla3.click();
            Thread.sleep(1000);

            System.out.println("Test 2 Tabla datos: Correcto");
        } catch (Exception e) {
            System.out.println("Test 2 Tabla datos: Error");
        }

        try{
            WebElement graficaa = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa.click();
            Thread.sleep(2000);

            WebElement grafica1B = driver.findElement(By.xpath("//a[@href='/grafica1B']"));
            grafica1B.click();
            Thread.sleep(2000);
            WebElement contaminanteNo2 = driver.findElement(By.xpath("//option[@value='data.iaqi.no2.v']"));
            contaminanteNo2.click();
            Thread.sleep(1000);
            WebElement mostrar = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar.click();
            Thread.sleep(1000);
            WebElement graficaa1 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa1.click();
            Thread.sleep(1000);

            WebElement grafica1P = driver.findElement(By.xpath("//a[@href='/grafica1P']"));
            grafica1P.click();
            Thread.sleep(2000);
            WebElement contaminanteSo2 = driver.findElement(By.xpath("//option[@value='data.iaqi.so2.v']"));
            contaminanteSo2.click();
            Thread.sleep(1000);
            WebElement mostrar1 = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar1.click();
            Thread.sleep(1000);
            WebElement graficaa2 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa2.click();
            Thread.sleep(1000);

            WebElement grafica1D = driver.findElement(By.xpath("//a[@href='/grafica1D']"));
            grafica1D.click();
            Thread.sleep(2000);
            WebElement contaminanteO3 = driver.findElement(By.xpath("//option[@value='data.iaqi.o3.v']"));
            contaminanteO3.click();
            Thread.sleep(1000);
            WebElement mostrar2 = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar2.click();
            WebElement graficaa3 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa3.click();
            Thread.sleep(1000);

            System.out.println("Test 3 Grafica 1: Correcto");
        } catch (Exception e) {
            System.out.println("Test 3 Grafica 1: Error");
        }

        try{
            WebElement graficaa4 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa4.click();
            Thread.sleep(2000);

            WebElement grafica2Bco = driver.findElement(By.xpath("//a[@href='/grafica2Bco']"));
            grafica2Bco.click();
            Thread.sleep(1000);
            WebElement fecha = driver.findElement(By.xpath("//option[@value='2017-00-00']"));
            fecha.click();
            Thread.sleep(1000);
            WebElement mostrar = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar.click();
            Thread.sleep(1000);
            WebElement graficaa5 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa5.click();
            Thread.sleep(1000);

            WebElement grafica2Bno2 = driver.findElement(By.xpath("//a[@href='/grafica2Bno2']"));
            grafica2Bno2.click();
            Thread.sleep(1000);
            WebElement fecha2 = driver.findElement(By.xpath("//option[@value='2016-00-00']"));
            fecha2.click();
            Thread.sleep(1000);
            WebElement mostrar3 = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar3.click();
            Thread.sleep(1000);
            WebElement graficaa6 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa6.click();
            Thread.sleep(1000);

            WebElement grafica2Bo3 = driver.findElement(By.xpath("//a[@href='/grafica2Bo3']"));
            grafica2Bo3.click();
            Thread.sleep(1000);
            WebElement fecha3 = driver.findElement(By.xpath("//option[@value='2017-00-00']"));
            fecha3.click();
            Thread.sleep(1000);
            WebElement mostrar4 = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar4.click();
            Thread.sleep(1000);
            WebElement graficaa7 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa7.click();
            Thread.sleep(1000);

            WebElement grafica2Bpm10 = driver.findElement(By.xpath("//a[@href='/grafica2Bpm10']"));
            grafica2Bpm10.click();
            Thread.sleep(1000);
            WebElement fecha4 = driver.findElement(By.xpath("//option[@value='2016-00-00']"));
            fecha4.click();
            Thread.sleep(1000);
            WebElement mostrar5 = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar5.click();
            Thread.sleep(1000);
            WebElement graficaa8 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa8.click();
            Thread.sleep(1000);

            WebElement grafica2Bso2 = driver.findElement(By.xpath("//a[@href='/grafica2Bso2']"));
            grafica2Bso2.click();
            Thread.sleep(1000);
            WebElement fecha5 = driver.findElement(By.xpath("//option[@value='2017-00-00']"));
            fecha5.click();
            Thread.sleep(1000);
            WebElement mostrar6 = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar6.click();
            Thread.sleep(1000);
            WebElement graficaa9 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa9.click();
            Thread.sleep(1000);

            System.out.println("Test 4 Grafica 2 Bermejales: Correcto");
        } catch (Exception e) {
            System.out.println("Test 4 Grafica 2 Bermejales: Error");
        }

        try{
            WebElement graficaa10 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa10.click();
            Thread.sleep(2000);

            WebElement grafica2Pco = driver.findElement(By.xpath("//a[@href='/grafica2Pco']"));
            grafica2Pco.click();
            Thread.sleep(1000);
            WebElement fecha = driver.findElement(By.xpath("//option[@value='2017-00-00']"));
            fecha.click();
            Thread.sleep(1000);
            WebElement mostrar = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar.click();
            Thread.sleep(1000);
            WebElement graficaa11 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa11.click();
            Thread.sleep(2000);

            WebElement grafica2Pno2 = driver.findElement(By.xpath("//a[@href='/grafica2Pno2']"));
            grafica2Pno2.click();
            Thread.sleep(1000);
            WebElement fecha2 = driver.findElement(By.xpath("//option[@value='2017-00-00']"));
            fecha2.click();
            Thread.sleep(1000);
            WebElement mostrar3 = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar3.click();
            Thread.sleep(1000);
            WebElement graficaa12 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa12.click();
            Thread.sleep(2000);

            WebElement grafica2Pso2 = driver.findElement(By.xpath("//a[@href='/grafica2Pso2']"));
            grafica2Pso2.click();
            Thread.sleep(1000);
            WebElement fecha4 = driver.findElement(By.xpath("//option[@value='2017-00-00']"));
            fecha4.click();
            Thread.sleep(1000);
            WebElement mostrar4 = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar4.click();
            Thread.sleep(1000);
            WebElement graficaa13 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa13.click();
            Thread.sleep(2000);

            System.out.println("Test 5 Grafica 2 Patra: Correcto");
        } catch (Exception e) {
            System.out.println("Test 5 Grafica 2 Patra: Error");
        }

        try{
            WebElement graficaa = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa.click();
            Thread.sleep(2000);

            WebElement grafica2Do3 = driver.findElement(By.xpath("//a[@href='/grafica2Do3']"));
            grafica2Do3.click();
            Thread.sleep(1000);
            WebElement fecha = driver.findElement(By.xpath("//option[@value='2017-00-00']"));
            fecha.click();
            Thread.sleep(1000);
            WebElement mostrar = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar.click();
            Thread.sleep(1000);
            WebElement graficaa14 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa14.click();
            Thread.sleep(2000);

            WebElement grafica2Dpm10 = driver.findElement(By.xpath("//a[@href='/grafica2Dpm10']"));
            grafica2Dpm10.click();
            Thread.sleep(1000);
            WebElement fecha2 = driver.findElement(By.xpath("//option[@value='2017-00-00']"));
            fecha2.click();
            Thread.sleep(1000);
            WebElement mostrar2 = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar2.click();
            Thread.sleep(1000);
            WebElement graficaa15 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa15.click();
            Thread.sleep(2000);

            WebElement grafica2Dso2 = driver.findElement(By.xpath("//a[@href='/grafica2Dso2']"));
            grafica2Dso2.click();
            Thread.sleep(1000);
            WebElement fecha3 = driver.findElement(By.xpath("//option[@value='2017-00-00']"));
            fecha3.click();
            Thread.sleep(1000);
            WebElement mostrar3 = driver.findElement(By.xpath("//input[@type='submit']"));
            mostrar3.click();
            Thread.sleep(1000);
            WebElement graficaa16 = driver.findElement(By.xpath("//li[@id='grafica']/a"));
            graficaa16.click();
            Thread.sleep(2000);

            System.out.println("Test 6 Grafica 2 Druzhba: Correcto");
        } catch (Exception e) {
            System.out.println("Test 6 Grafica 2 Druzhba: Error");
        }finally{
            driver.close();
        }

    }
}




